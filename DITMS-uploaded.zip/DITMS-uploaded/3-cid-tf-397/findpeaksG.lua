--local matrix = require "matrix"


function lorentzian(x,position,width)

  local L=#x

  local g={}

  for i=1,L do

    g[i]=1/(1+((x[i]-position)/(0.5*width))^2)

  end

  return g

end


function round(num, n)  --n��С������1λ
    if n > 0 then
        local scale = math.pow(10, n-1)
        return math.floor(num / scale + 0.5) * scale
    elseif n < 0 then
        local scale = math.pow(10, n)
        return math.floor(num / scale + 0.5) * scale
    elseif n == 0 then
        return num
    end
end


function val2ind(x,val)  --���ؾ�����ֵ�����Ԫ�ص���ֵ��ָ��

   local dif={}

   local index

   for i=1,#x do

     dif[i]=abs(x[i]-val)

   end


   local mins=min(unpack(dif))

   for i=1,#dif do

	 if dif[i]==mins then

	 index = i

	 end

   end

   local closestval=x[index]

   return index, closetval

end





function deriv(a)     --��б��

  local n=#a

  local d=zeros(n)

  d[1]=a[2]-a[1]

  d[n]=a[n]-a[n-1]

  for j=2,n-1 do

  d[j]=(a[j+1]-a[j-1])/2

  end

  return d

end


function fastsmooth(Y,w,type,ends)   --ѡ��ƽ������

    if type==1 then

	SmoothY=sa(Y,w,ends)

	elseif type==2  then

	SmoothY=sa(sa(Y,w,ends),w,ends)

	elseif type==3  then

	SmoothY=sa(sa(sa(Y,w,ends),w,ends),w,ends)

	end

  return SmoothY

end



function sa(Y,smoothwidth,ends)

  local w=round(smoothwidth,1)

  local SumPoints=summu(Y,1,w)

  local L=#Y

  local k

  local s=zeros(L)

  local halfw=round(w/2,1)

  for i=1,L-w do    --forѭ�������¶���i

    --print(k)

    s[i+halfw-1]=SumPoints

    SumPoints=SumPoints-Y[i]

    SumPoints=SumPoints+Y[i+w]

	k=i

  end

  s[k+halfw]=summu(Y,L-w+1,L)

  local SmoothY={}


  for i=1,#s do

    SmoothY[i]=s[i]/w

  end


  if ends==1 then

  local startpoint=(smoothwidth + 1)/2

    SmoothY[1]=(Y[1]+Y[2])/2

    for i=2,startpoint do

     --  SmoothY[k]=mean(Y(1:(2*k-1)))

	   SmoothY[i]=mean(Y,1,(2*i-1))

       SmoothY[L-i+1]=mean(Y,L-2*i+2,L)

    end

       SmoothY[L]=(Y[L]+Y[L-1])/2
  end

  return SmoothY

end


function summu(wwma,i,j)  --���

  local sum=0

--local ave=0

  for k=i,j do

    sum=sum+wwma[k]

  end

  return sum

end


function summu2(wwma)  --���ܺ�

  local sum=0

--local ave=0

  for k,v in pairs(wwma) do

    sum=sum+v

  end

  return sum

end


function mean(wwmb,i,j)

local ave=summu(wwmb,i,j)/(j-i+1)

return ave

end


function sign(value)

  local s

  if value>0 then  s=1
  elseif value==0 then s=0
  elseif value<0 then s=-1
  end

  return s

end


function zeros(size)  --����ȫ0����

  local list={}

  for i=1,size do

    list[i]=0

  end

  return list

end

function ones(size)  --����ȫ0����

  local list={}

  for i=1,size do

    list[i]=1

  end

  return list

end


function isnan(a)

  local st

  if type(a)==nil then

  st=1

  else st=0

  end



  return st

end


function isinf(a)

  local st

  if a==math.huge then

  st=1

  else st=0

  end

 -- print(st)

  return st

end


function rmnan(a)
-- Removes NaNs and Infs from vectors, replacing with nearest real numbers.
-- Example:
--  >> v=[1 2 3 4 Inf 6 7 Inf  9];
--  >> rmnan(v)
--  ans =
--     1     2     3     4     4     6     7     7     9
  local la=#a


  if isnan(a[1])==1 or isinf(a[1])==1 then a[1]=0 end

  --PrintTable(a)

  for point=1,la do

    if isnan(a[point])==1 or isinf(a[point])==1 then

        a[point]=a[point-1]

    end

  end

  return a

end

function polyfit(x,y,n)


  local f = {
    function(x) return 1 end,
    function(x) return x end,
    function(x) return x*x end,
  }

  -- Build matrix equation A * C = B
  local A = matrix(#x,#f)
  local B = matrix(#x,1)
  for i=1,#x do
    --local x = x[i]
    for j=1,#f do
      A[i][j] = f[j](x[i])
    end
    B[i][1] = y[i]
  end
  -- print(A, '\n--\n', B, '\n--')

  -- Solve for C's.
  local C = (A:transpose() * A)^-1 * A:transpose() * B
  -- local C, info = matrix.lss(A, B)
  local CT = C:transpose()[1]

  local result = {}
  for i=1,#f do result[i] = CT[i] end

  return result

end


function eval(a,b,c,x)
    return a + (b + c * x) * x
end


function regression(xa,ya)
    local n = #xa

    local xm = 0.0
    local ym = 0.0
    local x2m = 0.0
    local x3m = 0.0
    local x4m = 0.0
    local xym = 0.0
    local x2ym = 0.0

    for i=1,n do
        xm = xm + xa[i]
        ym = ym + ya[i]
        x2m = x2m + xa[i] * xa[i]
        x3m = x3m + xa[i] * xa[i] * xa[i]
        x4m = x4m + xa[i] * xa[i] * xa[i] * xa[i]
        xym = xym + xa[i] * ya[i]
        x2ym = x2ym + xa[i] * xa[i] * ya[i]
    end
    xm = xm / n
    ym = ym / n
    x2m = x2m / n
    x3m = x3m / n
    x4m = x4m / n
    xym = xym / n
    x2ym = x2ym / n

    local sxx = x2m - xm * xm
    local sxy = xym - xm * ym
    local sxx2 = x3m - xm * x2m
    local sx2x2 = x4m - x2m * x2m
    local sx2y = x2ym - x2m * ym

    local b = (sxy * sx2x2 - sx2y * sxx2) / (sxx * sx2x2 - sxx2 * sxx2)
    local c = (sx2y * sxx - sxy * sxx2) / (sxx * sx2x2 - sxx2 * sxx2)
    local a = ym - b * xm - c * x2m

	--print(a,b,c)

    --print("y = "..a.." + "..b.."x + "..c.."x^2")

    --for i=1,n do
    --    print(string.format("%2d %3d  %3d", xa[i], ya[i], eval(a, b, c, xa[i])))
    --end

	return c,b,a
end




function stdDev(t)  -- Find population standard deviation of table t

	local squares, avg = 0, mean(t,1,#t)

	for k, v in pairs(t) do

		squares = squares + ((avg - v) ^ 2)

	end

	local variance = squares / #t

	return math.sqrt(variance)

end



function gaussfit(x,y)

  local logyyy={}

  local maxy=max(unpack(y))

  local mu1=mean(x,1,#x) --ƽ��ֵ

  local mu2=stdDev(x)  --��׼��

  --print(maxy)

  for p=1,#y do

    if y[p]<(maxy/100) then y[p]=maxy/100 end

	logyyy[p]=math.log(abs(y[p]))

	x[p]=(x[p]-mu1)/mu2

  end --% for p=1:length(y),

  --local xa = {43.9700,43.9800,43.9900,44.0000,44.0100}
  --local ya = {1.3862,1.3863,1.3863,1.3861,1.3859}

  --PrintTable(logyyy)

  a,b,c = regression(x,logyyy)  --c,b,a

  --a,b,c=regression(xa,ya)

  --print(a,b,c)

  --coef=polyfit(x,logyyy,2)

  --PrintTable(logyyy)

  local c1=c
  local c2=b
  local c3=a

  --print(c3)
  --print(mu2)

  local MU={mu1,mu2}

  --print(mu2)


  local Position=-((MU[2]*c2/(2*c3))-MU[1])

  --print((c3*(c2/(2*c3))^2))

  local Height=exp(c1-c3*(c2/(2*c3))^2)

  local Width=MU[2]*2.35703/(sqrt(2)*sqrt(-1*c3))

    --print(Position)
--
 -- print(Height)

  --print(Width)

  --print(Height)


  return Position,Height,Width

end


function findpeaksG(x,y,SlopeThreshold,AmpThreshold,smoothwidth,peakgroup,smoothtype)




  smoothwidth=round(smoothwidth,1)  --С������λ��

  peakgroup=round(peakgroup,1)


  if smoothwidth>1 then

    d=fastsmooth(deriv(y),smoothwidth,smoothtype)

    else

    d=deriv(y)

  end



  --PrintTable(d)


local vectorlength=#y

local peak=1

local n=round(peakgroup/2+1,1)

local P={}


  for j=2*round(smoothwidth/2,1)-1,#y-smoothwidth-1 do

     if sign(d[j]) > sign (d[j+1]) then -- Detects zero-crossing

        if d[j]-d[j+1] > SlopeThreshold then --% if slope of derivative is larger than SlopeThreshold

			if y[j] > AmpThreshold then  --% if height of peak is larger than AmpThreshold

				--	print("hello")


				xx=zeros(peakgroup)

				yy=zeros(peakgroup)

				for i=1,peakgroup do --Create sub-group of points near peak

				  groupindex=j+i-n+2

  				  if groupindex<1 then groupindex=1 end

				  if groupindex>vectorlength then groupindex=vectorlength end

				  xx[i]=x[groupindex]

				  yy[i]=y[groupindex]

				end

				--PrintTable()

				if peakgroup>2 then

				--PrintTable(yy)


				 local Height, Position, Width=gaussfit(xx,yy)

				  PeakX=Position  -- % Compute peak position and height of fitted parabola

				  PeakY=Height

				  MeasuredWidth=Width

				 --print(Width)

                else

				  PeakY=max(unpack(yy))

				  pindex1,pindex2=val2ind(yy,PeakY)

				  PeakX=xx[pindex1]

				  MeasuredWidth=0

				end

				--% Construct matrix P. One row for each peak
                --% detected, containing the peak number, peak
                --% position (x-value) and peak height (y-value).
                --% If peak measurements fails and results in NaN, skip this
                --% peak
                if isnan(PeakX)==1 or isnan(PeakY)==1 or PeakY<AmpThreshold then

                    --% Skip this peak
                else --% Otherwiase count this as a valid peak

				  local row={round(peak,1),PeakY,PeakX,MeasuredWidth,1.0646*PeakY*MeasuredWidth}

				  --PrintTable(row)

                  -- print(MeasuredWidth)
				  table.insert(P, row)

				  peak=peak+1-- % Move on to next peak

                end


			end
		end
	 end

	end

	return P

end



--local ax={}

--local bx={}


--for i=1,5001 do

--  ax[i]=0.01*(i-1)

--end


--for i=1,#ax  do

--  bx[i]=(1+cos(ax[i]))^2

--end

--ax={0, 1,  2,  3,  4,  5,   6,   7,   8,   9,  10}
--bx={1, 6, 17, 34, 57, 86, 121, 162, 209, 262, 321}

--regression(ax,bx)
--gaussfit({1,2,3},{1,2,1})
--P=findpeaksG(ax,bx,0,-1,5,5,3)

--local xx = {0, 1,  2,  3,  4,  5,   6,   7,   8,   9,  10}
--local yy = {1, 6, 17, 34, 57, 86, 121, 162, 209, 262, 321}

--c,a,b=regression(xx, yy)

--print(a,b,c)

--PrintTable(P)

--gaussfit(xx,yy)



--os.execute 'pause'
