-- traputil.lua - Functionality shared by the ion trap demo programs.
--
-- This file provides various shared variables and global functions
-- useful for the ion trap demos.
--
-- D.Manura-2006-08 - based on PRG code from SIMION 7.0 - David A. Dahl 1995
-- (c) 2006 Scientific Instrument Services, Inc. (Licensed under SIMION 8.0)
--=======================================================================

-- if checkglobals then checkglobals() end

simion.workbench_program()

local STAT = require 'simionx.Statistics'
local PLOT = simion.import 'plotlib.lua'
local HS1 = simion.import("collision_hs1.lua")

luafft = require "luafft"
--simion.import 'findpeaksG.lua'


adjustable plot_enable = 1

---- adjustable during flight

-- ion trap voltage control
adjustable coolingtime        = 10      --��λ��΢��
--adjustable _qz_tune_start     =       -- Mathieu Qz tuning point
adjustable _U_tune            = 200
adjustable _Uac_tune_start    = 0
adjustable _Uac_tune_end      = 0
adjustable floatDC            = 0
adjustable frontcap           = 20	      -- sims target voltage
adjustable rearcap            = 20
adjustable cidtime            = 12000           --rf�ܹ���ɨ��ʱ��
adjustable rftime             = 5000
adjustable mion               = 556.6
adjustable cootime            = 100
adjustable phase_angle_deg          = 0.0   -- entry phase angle of ion (deg)
adjustable freqency_hzrfs           = 0.500E6 -- RF frequency of quad in (hz)
adjustable freqency_hzrfe1          = 0.5963E6--0.655E6 -- RF frequency of quad in (hz)
adjustable freqency_hzrfe2          = 0.500E6--0.655E6 -- RF frequency of quad in (hz)
--adjustable freqency_hzac            = 1.3E5
--adjustable effective_xradius_in_cm   = 0.4  -- effective quad radius r0 (cm)
--adjustable effective_zradius_in_cm   = 0.5 -- AC frequency of quad
-- display
adjustable pe_update_each_usec      = 0.001   -- potential energy display
adjustable radius = 4.5
adjustable zradius = 4.4

adjustable litl = 0.05E6

adjustable ritl = 0.22E6

adjustable masslit= 30000


adjustable step_size = 0.002  -- microseconds

adjustable _npoints = 100

local function linrange(first, last, n)
  local t = {}
  for i=1,n do t[i] = first + (last-first)*((i-1)/(n-1)) end
  return t
end

function segment.tstep_adjust()

  ion_time_step = math.min(ion_time_step, step_size)

end                                           -- (usec)



-- Trigger periodic PE surface display updates.
-- This is designed to be called inside a SIMION other_actions segment.



local next_pe_update = 0.0 -- next time to update PE surface
local function pe_update()
    -- If TOF reached next PE display update time...
    if ion_time_of_flight >= next_pe_update then
        -- Request a PE surface display update.
        sim_update_pe_surface = 1
        -- Schedule next PE display update time (usec).
        next_pe_update = ion_time_of_flight + pe_update_each_usec
    end
end
segment.other_actions = pe_update


-- Default SIMION initialize segment for ion trap example.
-- This segment is called on every particle creation.
function segment.initialize()
    -- Enable rerun mode (used only for side-effect of disabling trajectory
    -- file saving).
    --sim_rerun_flym = 1
   -- randomize_particles()
end

-- Add a new child particle using the parameters
-- in table t.  Parameters can be omitted, in which case
-- they default to the values of the current particle.

-- Default SIMION fast_adjust segment for ion trap example.
-- This segment is called to modify electrode voltages.
--local scaled_rf   -- scaled RF base




function segment.flym()

  a = {}                          -- the table of tof
  b = {}                          -- the table of peak's time
  c = {}                          -- the table of peak's height
  d = {}
  e = {}
  b1={}
  b2={}
  plotdata = {}   -- data to be plotted total

  fA=0

  sim_trajectory_image_control = 1  -- don't keep trajectories
  --sim_trajectory_quality = 0 -- fastest trajectory integration
  local fAs = linrange(freqency_hzrfs, freqency_hzrfe1, _npoints)

  for ia = 1, #fAs do

    fA= fAs[ia]

	--print_run_params()

    -- Perform trajectory calculation run.
    run()

	is_first=1

  end

  PLOT.plot(e)

end


function segment.fast_adjust()

 local omegarfs     -- frequency (rad/usec)
 local omegarfe1
 local omegarfe2
--local omegaac
 local fpertime1
 local fpertime2
 local theta       -- phase offset (rad)
 is_first  = true   -- first call flag
 local Uac
 local fra
    ---- Generate trap RF voltages with fast adjust.
    -- For efficiency, we calculate some variables only once.
    if is_first then
        is_first = false
        -- scaled_rf is the scaling constant (1/4)w^2r0^2 used in
        -- the equations for DC and RF voltages U and V below.
        -- We include in it a conversion factor for SIMION units:
        --   conversion_factor ~= (1/4) * (1.66053886*10^-27 kg/amu) *
        --                                (1.602176462*10^-19 C/e)^-1 *
        --                                (2*PI rad/cycle)^2 *
        --                                (0.01 m/cm)^2
        --                     ~= 1.02291E-11 ~= 1.022442E-11
        --scaled_rf = 1.022442E-11 * freqency_hzrf^2 * effective_radius_in_cm^2
		--local Teject=3.198*10^(-5)*(mion*qeject/_U_tune)*r0
		--local feject=1/Teject

        --local Ts=3.198*10^(-5)*(mion*qs/_U_tune)*r0
        --local fs=1/Ts

        theta     = rad(phase_angle_deg)              -- phase angle (rad)
        omegarfs  = fA  * 2 * 3.14159 * 1E-6  -- frequency (rad/usec) ���ٶ
		omegarfe1 = freqency_hzrfe1 * 2 * 3.14159 * 1E-6  -- frequency (rad/usec) ���ٶ��
		omegarfe2 = freqency_hzrfe2 * 2 * 3.14159 * 1E-6  -- frequency (rad/usec) ���ٶ�?
        --omegaac   = freqency_hzac   * 2 * 3.14159 * 1E-6  -- frequency
		fpertime1 = (omegarfe1 - omegarfs)/cidtime  --ע������upertime1������λ��fa
		fpertime2 = (omegarfe2 - omegarfs)/rftime   --ע������upertime1������λ��fa
		fcidtime     = (freqency_hzrfe1 - freqency_hzrfs)/cidtime
	    Upertime2 = (_Uac_tune_end - _Uac_tune_start)/rftime
		qs=8*1.602*10^(-19)*_U_tune*6.022*10^23/(10^(-9)*(radius^2+zradius^2)*mion)--*(2*pi*frequency)^2;
		--omegarf =feject*2*3.14159 * 1E-6
		--omegarfs=fs*2*3.14159 * 1E-6
    end
    -- Calculate DC and RF voltages U and V from tuning factors.
    -- This uses the standard equations
    --   U = -(a_z/8)(m/e)w^2r0^2      (DC factor)
    --   V =  (q_z/4)(m/e)w^2r0^2      (RF factor)
    -- where
-- Import waveform library.
-- Install waveform.
    --   w is angular frequency 2*PI*f given frequency f;
    --   r0 is radius of ring electrode.
    --   2*z0 is distance between end cap electrodes.
    --   r0^2 = 2*z0^2 as required for ideal (non-stretched) trap.
    -- Note: values are recalculated since the dependent variables can
    -- be adjusted during the simulation.
	--local qzwwm
	--local rfwwm

	--local Upertime2 = (_Uac_tune_end - _Uac_tune_start)/rfactime

    -- Set electrode voltages.
	 --   print(fs)

	if ion_time_of_flight<=coolingtime then  --��ȴ

		Uac  = 0

		frf  = omegarfs

		fra  = 0

	elseif ion_time_of_flight>coolingtime and ion_time_of_flight <= (cidtime + coolingtime) then --CID

	    Uac  = _Uac_tune_start --+ (ion_time_of_flight-coolingtime)*Upertime2

	    frf  = omegarfs --+ (ion_time_of_flight-coolingtime)*fpertime1

		fra  = frf/3

	elseif ion_time_of_flight>(cidtime + coolingtime) and ion_time_of_flight<=(cidtime + coolingtime+cootime) then  --��ȴ2

	    Uac  = 0

		frf  = omegarfs

		fra  = 0

	elseif ion_time_of_flight>(cidtime + coolingtime+cootime) and ion_time_of_flight<=(cidtime + coolingtime+cootime+rftime) then

		Uac  = _Uac_tune_start

		frf  = omegarfs + (ion_time_of_flight-coolingtime)*fpertime2

		fra  = 2*frf/3

	elseif ion_time_of_flight>(cidtime + coolingtime+cootime+rftime) then

	    Uac  = 0

		frf  = omegarfs

		fra  = 0

	end


	if sin(theta + ion_time_of_flight * frf)<=0  then

	   if sin(theta + ion_time_of_flight * fra)<=0 then

	   adj_elect03 = floatDC - _U_tune

	   adj_elect04 = floatDC - _U_tune

	   adj_elect01 = floatDC + Uac  + _U_tune

	   adj_elect02 = floatDC - Uac  + _U_tune

	   else

	   adj_elect03 = floatDC - _U_tune

	   adj_elect04 = floatDC - _U_tune

	   adj_elect01 = floatDC - Uac  + _U_tune

	   adj_elect02 = floatDC + Uac  + _U_tune

	   end

	else

	   if sin(theta + ion_time_of_flight * fra)<=0 then

	   adj_elect03 = floatDC + _U_tune

	   adj_elect04 = floatDC + _U_tune

	   adj_elect01 = floatDC + Uac  - _U_tune

	   adj_elect02 = floatDC - Uac  - _U_tune

	   else

	   adj_elect03 = floatDC + _U_tune

	   adj_elect04 = floatDC + _U_tune

	   adj_elect01 = floatDC - Uac  - _U_tune

	   adj_elect02 = floatDC + Uac  - _U_tune

	   end

	end

	   adj_elect06 = rearcap

	   adj_elect05 = frontcap

end
	--rfwwm=qzwwm*scaled_rf*mz


-- Default SIMION terminate segment for ion trap example.
-- This segment is called on each particle termination.
function segment.terminate()
        -- Count how many particles are accepted in this run.
        --if ion_py_mm > -0.8 and ion_py_mm < -0.8 and ion_px_mm < 4 then -- hitting detector

    --sim_rerun_flym = 0

end


function val2ind(x,val)  --���ؾ�����ֵ�����Ԫ�ص���ֵ��ָ��

   local dif={}

   local index

   for i=1,#x do

     dif[i]=abs(x[i]-val)

   end


   local mins=min(unpack(dif))

   for i=1,#dif do

	 if dif[i]==mins then

	 index = i

	 end

   end

   local closestval=x[index]

   return index, closetval

end

function segment.terminate_run()

  local spec = fft(plotdata, true)  --ǿ���ƻ���c�б�

     for i=2,#spec/2 do

     local cx=spec[i]

     complex.get(cx)

	 ampli=(cx[1]^2+cx[2]^2)^0.5

  --phas=atan(cx[2]/cx[1])

	 d[i]=(i-1)/#spec*1/step_size*10^6

	-- PrintTable(d)
	 if d[i]> litl and d[i] < ritl then

	  a[i]=ampli

      table.insert(b1, d[i])

	  table.insert(b2, a[i])

	  table.insert(b,{d[i],a[i]})

     end

     end

	 local maxvalue = max(unpack(b2))

	 pindex1,pindex2 = val2ind(b2,maxvalue)

	 --P=findpeaksG(b1,b2,0.0001,masslit,5,2,3)--
	 --c=P[1]

	 --table.insert(e,{(fA-freqency_hzrfs)/fcidtime,c[3],fA})

	 table.insert(e,{(fA-freqency_hzrfs)/fcidtime,b1[pindex1],fA/3})

	-- PrintTable(e)

  -- compute histogram.
  --if plot_enable == 1 then PLOT.plot(b) end  --����ʵʱ���ӹ켣ͼ

     plotdata = {}   -- data to be plotted total

	 P={}
	 b1={}
	 b2={}
	 a={}
	 c={}
	 d={}
	 spec={}
	 b={}
	 --e={}

  --max = math.max(unpack(a))*1000
  --min  = math.min(unpack(a))*1000
  --print(max-min)
  --Print histogram to Log window.
  --print('TOF','freq')
  --print(hist)
  --PrintTable(plotdata2)
  --print(c[2])
  --print(size)
  --spec[i]:abs()
  --PLOT.plot(result)

end



function segment.other_actions()


local stop
local realtime

   --sim_trajectory_quality = -1

if ion_time_of_flight >= (cidtime + coolingtime)  then

	ion_splat = 1

end
  --sim_trajectory_quality = -1
  -- Terminate run (if stop flag set).

if ion_time_of_flight >= coolingtime then

	 if not e.header then
      e.header = {
        'time/us',
        'secular frequency/Hz',
		'frequency/Hz'
		--'Ey(eV)'
     --   'charge (' .. units_charge_C .. ' C',
     --   'y (' .. units_position_mm .. ' mm)',
     --   'vx (' .. units_velocity_mmusec .. ' mm/usec)',
     --   'vy (' .. units_velocity_mmusec .. ' mm/usec)'
      }
     end

     local realtime=ion_time_of_flight-coolingtime

	--realdisx=math.sqrt(ion_pz_mm^2)

    --table.insert(d,realdisx)
	-- frf=frf*10^6

	-- mathq = qs/frf^2  --ʵʱ�������޲���

	-- table.insert(c,mathq)

    --table.insert(a, ion_time_of_flight)

	--PrintTable(c)
	--if realtime%0.1<=0.05 then
	if floor(realtime/step_size)%1==0 then   --����������

	local row = {

      realtime,
	  ion_pz_mm
      --INDUCE.current/units_current_A,
	  --c[#c-1]

     -- ion_py_mm / units_position_mm,
	 -- ion_px_mm / units_position_mm,
      --(ion_vx_mm^2+ion_vy_mm^2+ion_vz_mm^2) / units_position_mm,  --ion_vx_mm / units_velocity_mmusec,
     -- ion_vy_mm / units_velocity_mmusec
    }

    table.insert(plotdata, row[2])

	end

	--end

end

  if stop then ion_splat = 1; return end

   --  if stop then ion_splat = 1; return end

  -- Simulate some type of interaction (just as an example).

	--orgindis=math.sqrt(ion_py_mm^2+ion_px_mm^2+ion_pz_mm^2)

end


key = ""
function PrintTable(table , level)
  level = level or 1
  local indent = ""
  for i = 1, level do
    indent = indent.."  "
  end

  if key ~= "" then
    print(indent..key.." ".."=".." ".."{")
  else
    print(indent .. "{")
  end

  key = ""
  for k,v in pairs(table) do
     if type(v) == "table" then
        key = k
        PrintTable(v, level + 1)
     else
        local content = string.format("%s%s = %s", indent .. "  ",tostring(k), tostring(v))
      print(content)
      end
  end
  print(indent .. "}")

end
